document.addEventListener("DOMContentLoaded", function () {
    alert("Welcome to my personal website!");
});

// Example: Toggle a dark mode feature
const darkModeToggle = document.getElementById("darkModeToggle");
const body = document.body;

darkModeToggle.addEventListener("click", function () {
    body.classList.toggle("dark-mode");
});
